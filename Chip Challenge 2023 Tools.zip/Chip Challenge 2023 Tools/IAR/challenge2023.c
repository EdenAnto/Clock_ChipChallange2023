#include "msp430.h"
#include "LCD_Utilities.h"
#define notes 25
#define SI0 1988
#define DO 1908
#define RE 1704
#define MI 1511
#define FA 1427
#define SOL 1271
#define LA 1139
#define SI 996
#define DO2 954
#define MUTE 0		// no signal at all
unsigned int jonathan[] =  {SOL, MI, MI, FA, RE,RE, DO, RE, MI, FA,SOL,SOL,SOL,SOL,MI,MI,FA,RE,RE,DO,MI,SOL,SOL,DO,MUTE};  // play "yonatan ha'katan"
//unsigned int dayenu[] = { 
//    MI, MI, SOL, FA,MUTE, FA, FA, LA, SOL,MUTE, SOL, SOL, DO, SI,MUTE, SI,
//    SI, SOL, LA, SI, DO, MUTE,MUTE,MUTE,MUTE};
unsigned int alarmSong[] ={MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,
                          MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,MUTE,MUTE};

unsigned int ma_Nishtana[] = { 
   DO , LA, LA, LA ,MI,MUTE, DO, LA, LA, LA,MUTE, MI, SOL, FA, RE,MI, MUTE,
    MI, SOL, FA, RE,MI,MUTE,MI, SOL, FA, RE,MI,MUTE,DO,MI,MI,MI,RE,SI,DO,LA,LA,LA,MUTE,
    MI, SOL, FA,RE,FA};
#define ARRAY_SIZE 24

int flag=0;
int i=0;
void wait(int ms) ;
void ChangeSong1();
void ChangeSong2();
void ChangeMute();

void main()
{

 
  
  WDTCTL = WDTPW | WDTHOLD;	// Stop watchdog timer
  PM5CTL0 &= ~LOCKLPM5;		// Clear locked IO Pins
  P1DIR |= BIT0;		// Set P1.0 to output direction
  TA0R = 0x0000; 
  
  P1REN |= BIT1;
  P1OUT |= BIT1;

  ChangeSong2();
  
  P1SEL0 |= BIT7;               //Selecting TA0.2 (OUT2) line as output function
  P1SEL1 |= BIT7;
  P1DIR |= BIT7;                // set P1.7 (meaning TA0.2) as output
  
  TA1CTL = TASSEL__ACLK + MC__UP + TACLR + ID__1 + TAIE;       
  TA0CTL = TASSEL__SMCLK + MC__UP + TACLR + ID__1;       
  TA1CCR0 = 32768;              // max count limit 1 sec cycle
  TA0CCR0 = alarmSong[0];
  TA0CCTL2 |= OUTMOD_2; 
  
  LCDInit();
  LCD_All_Off();

  


  while(1){
    if(!(P1IN & BIT1))
    {
      if (flag==0)
      {
        ChangeSong1();
        flag = 1;
      }
      else if(flag==1)
      {
         ChangeMute();
        flag = 2;

      }
      else
      {
        ChangeSong2();
        flag=0;
      }
        
    }
    wait(250);
    if ((P1IN & BIT3))
        {
          //P1OUT ^= BIT0;// Toggle P1.0
         TA0CCR0 = alarmSong[i++];
         TA0CCR2 = 0.5 * TA0CCR0;
          if (i == 25)
              i = 0;
          Display_word("ALARM");
          wait(250);
          Display_word("      ");


        }
        else {
          TA0CCR0 = MUTE;
          TA0CCR2=MUTE;
          Display_word("CHALLENGE INTEL MOBILEYE ");
          modifyStringLeft("CHALLENGE INTEL MOBILEYE ");

          }
  }
        
  _BIS_SR (LPM3_bits + GIE);
}


void wait(int ms) {
	int i, j;
	for(i=0; i<ms; i++)
          for(j=0; j<200; j++);     
}

void modifyStringLeft(char str[]) {
    char firstChar = str[0];
    for (int i = 1; i < 25; i++) {
        str[i-1] = str[i];
    }
    str[24] = firstChar;
}

void ChangeSong1 (){
  for (int i = 0; i < ARRAY_SIZE; i++) {
        alarmSong[i] = ma_Nishtana[i];
    }
  
}

void ChangeSong2 (){
  for (int i = 0; i < ARRAY_SIZE; i++) {
        alarmSong[i] = jonathan[i];
    }
  
}


void ChangeMute(){
  for (int i = 0; i < ARRAY_SIZE; i++) {
        alarmSong[i] = MUTE;
    }
}






