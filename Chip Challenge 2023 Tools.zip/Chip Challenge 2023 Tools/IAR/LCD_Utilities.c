#include "LCD_Utilities.h"

const unsigned char lcd_num[10] = { 0xFC, 0x60, 0xDB, 0xF3, 0x67, 0xB7, 0xBF, 0xE4,  0xFF, 0xF7};

void LCDInit ()
{
    PJSEL0 = BIT4 | BIT5;                   // For LFXT

    // Initialize LCD segments 0 - 21; 26 - 43
    LCDCPCTL0 = 0xFFFF;
    LCDCPCTL1 = 0xFC3F;
    LCDCPCTL2 = 0x0FFF;

    // Disable the GPIO power-on default high-impedance mode
    // to activate previously configured port settings
    PM5CTL0 &= ~LOCKLPM5;

    // Configure LFXT 32kHz crystal
    CSCTL0_H = CSKEY >> 8;                  // Unlock CS registers
    CSCTL4 &= ~LFXTOFF;                     // Enable LFXT
    do
    {
      CSCTL5 &= ~LFXTOFFG;                  // Clear LFXT fault flag
      SFRIFG1 &= ~OFIFG;
    }while (SFRIFG1 & OFIFG);               // Test oscillator fault flag
    CSCTL0_H = 0;                           // Lock CS registers

    // Initialize LCD_C
    // ACLK, Divider = 1, Pre-divider = 16; 4-pin MUX
    LCDCCTL0 = LCDDIV__1 | LCDPRE__16 | LCD4MUX | LCDLP;

    // VLCD generated internally,
    // V2-V4 generated internally, v5 to ground
    // Set VLCD voltage to 2.60v
    // Enable charge pump and select internal reference for it
    LCDCVCTL = VLCD_1 | VLCDREF_0 | LCDCPEN;

    LCDCCPCTL = LCDCPCLKSYNC;               // Clock synchronization enabled

    LCDCMEMCTL = LCDCLRM;                   // Clear LCD memory
    LCDCCTL0 |= LCDON;

 }

void LCD_All_On(){

  int i;
  char *ptr = 0;
  ptr += 0x0A20;		// LCD memory starts at 0x0A20
  for (i = 0;i<21;i++)
  *ptr++ = 0xFF;

}



void LCD_All_Off(){
  int i;
  char *ptr = 0;
  ptr += 0x0A20;		// LCD memory starts at 0x0A20
  for (i = 0;i<21;i++)
    *ptr++ = 0;
}


void Display_Number (long n){
  int i=0;
    char *Ptr2Num[6] = {0};
    Ptr2Num[0] +=0xA29;
    Ptr2Num[1] +=0xA25;
    Ptr2Num[2] +=0xA23;
    Ptr2Num[3] +=0xA32;
    Ptr2Num[4] +=0xA2E;
    Ptr2Num[5] +=0xA27;
    
    LCD_All_Off();
    if(n<0){
    	n=-n;
    	SIGN_LESS_ON;
    }
      if (n>999999){
    	SIGN_ERR_ON;
    	return;
      }
    
    do {
        *Ptr2Num[5-i] = lcd_num[n%10];
         i++;
         n = n/10;  
    }while ( n );
}

void Display_digit (int p,int d){
  char *Ptr2Num[6] = {0};
    Ptr2Num[0] +=0xA29;
    Ptr2Num[1] +=0xA25;
    Ptr2Num[2] +=0xA23;
    Ptr2Num[3] +=0xA32;
    Ptr2Num[4] +=0xA2E;
    Ptr2Num[5] +=0xA27;
    *Ptr2Num[p-1]=lcd_num[d];
}

int letter_loc(char l){
  if (l==' ')
    return 26;
  return (int)(l-'A');
}

void Display_letter(int pos,char l){
  int loc=letter_loc(l);
  switch(pos){
  case 1:{ A1=alphabetBig[loc][0]; A1r2=alphabetBig[loc][1];break;}
  case 2:{ A2=alphabetBig[loc][0]; A2r2=alphabetBig[loc][1];break;}
  case 3:{ A3=alphabetBig[loc][0]; A3r2=alphabetBig[loc][1];break;}
  case 4:{ A4=alphabetBig[loc][0]; A4r2=alphabetBig[loc][1];break;}
  case 5:{ A5=alphabetBig[loc][0]; A5r2=alphabetBig[loc][1];break;}
  case 6:{ A6=alphabetBig[loc][0]; A6r2=alphabetBig[loc][1];break;}
  }
}

void Display_word(const char str[]) {
    for (int i = 0; str[i] != '\0'; i++) {
        Display_letter(i+1, str[i]);
    }
}


const char alphabetBig[27][2] =
{
    {0xEF, 0x00},  /* "A" LCD segments a+b+c+e+f+g+m */
    {0xF1, 0x50},  /* "B" */
    {0x9C, 0x00},  /* "C" */
    {0xF0, 0x50},  /* "D" */
    {0x9F, 0x00},  /* "E" */
    {0x8F, 0x00},  /* "F" */
    {0xBD, 0x00},  /* "G" */
    {0x6F, 0x00},  /* "H" */
    {0x90, 0x50},  /* "I" */
    {0x78, 0x00},  /* "J" */
    {0x0E, 0x22},  /* "K" */
    {0x1C, 0x00},  /* "L" */
    {0x6C, 0xA0},  /* "M" */
    {0x6C, 0x82},  /* "N" */
    {0xFC, 0x00},  /* "O" */
    {0xCF, 0x00},  /* "P" */
    {0xFC, 0x02},  /* "Q" */
    {0xCF, 0x02},  /* "R" */
    {0xB7, 0x00},  /* "S" */
    {0x80, 0x50},  /* "T" */
    {0x7C, 0x00},  /* "U" */
    {0x0C, 0x28},  /* "V" */
    {0x6C, 0x0A},  /* "W" */
    {0x00, 0xAA},  /* "X" */
    {0x00, 0xB0},  /* "Y" */
    {0x90, 0x28},   /* "Z" */
    {0, 0}   /* POWER OFF */

};


